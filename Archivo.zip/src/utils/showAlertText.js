const showAlertText = (color) =>{
    alert(`señor usuario el color de la pantalla ha cambiado a ${color}`)
}

export default showAlertText