const colors = {
    rojo: { background: 'red', name:'Rojo'},
    azul: { background: 'blue', name: 'Azul'}
}

export default colors